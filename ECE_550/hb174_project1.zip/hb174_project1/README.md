# Project Checkpoint 1
 - Author: Haochi Bai
 - Date: 2021/9/13
 - Course: ECE 550DK, Dukekunshan University, China
 - Term: 2021fall
 - Professor Xin Li

## Duke Community Standard, Affirmation
 I affirm that each submission complies with the Duke Community Standard and the guidelines set forth for this assignment.  

## Project Text Discription